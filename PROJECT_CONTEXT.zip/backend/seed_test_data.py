from app import app
from models import db, User, StudentProfile, CompanyProfile, PlacementDrive, Application, Placement
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta


# Helper: build an interview slot (start, end) relative to "now".
# Positive days = future interview, negative days = one that already happened
# (used for students who are already at the offer/placed stage).
def interview_slot(days, hour, minutes=45):
    start = datetime.utcnow() + timedelta(days=days, hours=hour)
    end = start + timedelta(minutes=minutes)
    return start, end


def seed_data():
    with app.app_context():
        print("=" * 60)
        print("SEEDING TEST DATA")
        print("=" * 60)

        # ─────────────────────────────────────────────
        # STUDENTS (6 students)
        # Covers: different branches, a range of CGPAs/years,
        # and one BLACKLISTED student (is_active=False).
        # ─────────────────────────────────────────────
        test_students = [
            {'username': 'alice_s',   'email': 'alice@test.com',   'full_name': 'Alice Sharma',   'branch': 'Computer Science and Engineering',       'cgpa': 9.2, 'year': 4, 'skills': 'Python, React',   'phone': '9876543211', 'experience': '6-month internship at a fintech startup', 'is_active': True},
            {'username': 'bob_k',     'email': 'bob@test.com',     'full_name': 'Bob Kumar',      'branch': 'Computer Science and Engineering',       'cgpa': 7.8, 'year': 4, 'skills': 'Java, Spring',    'phone': '9876543212', 'is_active': True},
            {'username': 'charlie_p', 'email': 'charlie@test.com', 'full_name': 'Charlie Patel',  'branch': 'Information Technology', 'cgpa': 8.5, 'year': 4, 'skills': 'Vue, Flask',      'phone': '9876543213', 'is_active': True},
            {'username': 'diana_m',   'email': 'diana@test.com',   'full_name': 'Diana Mehta',    'branch': 'Electronics and Communication Engineering',            'cgpa': 6.5, 'year': 3, 'skills': 'C, Embedded',     'phone': '9876543214', 'is_active': True},
            {'username': 'evan_r',    'email': 'evan@test.com',    'full_name': 'Evan Roy',       'branch': 'Computer Science and Engineering',       'cgpa': 8.9, 'year': 4, 'skills': 'Go, Kubernetes',  'phone': '9876543215', 'experience': 'Open-source contributor', 'is_active': True},
            {'username': 'fiona_l',   'email': 'fiona@test.com',   'full_name': 'Fiona Lopez',    'branch': 'Mechanical Engineering',             'cgpa': 7.2, 'year': 4, 'skills': 'CAD, MATLAB',     'phone': '9876543216', 'is_active': False},  # blacklisted
        ]

        created_students = {}

        for s in test_students:
            existing = User.query.filter_by(username=s['username']).first()
            if existing:
                profile = StudentProfile.query.filter_by(user_id=existing.id).first()
                if profile:
                    created_students[s['username']] = profile
                continue

            user = User(
                username=s['username'],
                email=s['email'],
                password=generate_password_hash('test123'),
                role='student',
                is_active=s.get('is_active', True)
            )
            db.session.add(user)
            db.session.flush()

            profile = StudentProfile(
                user_id=user.id,
                full_name=s['full_name'],
                branch=s['branch'],
                cgpa=s['cgpa'],
                year=s['year'],
                skills=s['skills'],
                phone=s['phone'],
                experience=s.get('experience')
            )
            db.session.add(profile)
            db.session.flush()
            created_students[s['username']] = profile
            active_note = '' if s.get('is_active', True) else ' (BLACKLISTED)'
            print(f"  Created student: {s['full_name']}{active_note}")

        db.session.commit()

        # ─────────────────────────────────────────────
        # COMPANIES (4 companies)
        # Covers every approval_status: approved / pending / rejected.
        # ─────────────────────────────────────────────
        test_companies = [
            {'username': 'tcs_hr',     'email': 'hr@tcs.com',     'company_name': 'TCS',     'industry': 'IT Services', 'location': 'Chennai',   'approval_status': 'approved', 'is_active': True},
            {'username': 'google_hr',  'email': 'hr@google.com',  'company_name': 'Google',  'industry': 'IT',          'location': 'Bangalore', 'approval_status': 'pending',  'is_active': True},
            {'username': 'infosys_hr', 'email': 'hr@infosys.com', 'company_name': 'Infosys', 'industry': 'IT Services', 'location': 'Pune',      'approval_status': 'approved', 'is_active': True},
            {'username': 'wipro_hr',   'email': 'hr@wipro.com',   'company_name': 'Wipro',   'industry': 'IT Services', 'location': 'Hyderabad', 'approval_status': 'rejected', 'is_active': True},
        ]

        created_companies = {}

        for c in test_companies:
            existing = User.query.filter_by(username=c['username']).first()
            if existing:
                profile = CompanyProfile.query.filter_by(user_id=existing.id).first()
                if profile:
                    created_companies[c['company_name']] = profile
                continue

            user = User(
                username=c['username'],
                email=c['email'],
                password=generate_password_hash('test123'),
                role='company',
                is_active=c.get('is_active', True)
            )
            db.session.add(user)
            db.session.flush()

            profile = CompanyProfile(
                user_id=user.id,
                company_name=c['company_name'],
                industry=c['industry'],
                location=c['location'],
                hr_contact='9876543210',
                website='https://example.com',
                description=f"{c['company_name']} company",
                approval_status=c['approval_status']
            )
            db.session.add(profile)
            db.session.flush()
            created_companies[c['company_name']] = profile
            print(f"  Created company: {c['company_name']} ({c['approval_status']})")

        db.session.commit()

        # ─────────────────────────────────────────────
        # PLACEMENT DRIVES (6 drives)
        # Covers every drive status: approved / pending / rejected / closed,
        # and a mix of branch/CGPA eligibility rules.
        # ─────────────────────────────────────────────
        tcs = created_companies.get('TCS')
        infosys = created_companies.get('Infosys')

        test_drives = []
        if tcs:
            test_drives += [
                {'company_id': tcs.id, 'job_title': 'Software Developer', 'job_description': 'Full-stack development role', 'eligibility_branch': 'Computer Science and Engineering,Information Technology', 'min_cgpa': 7.0, 'eligibility_year': 4, 'salary': 8.5, 'status': 'approved', 'deadline_days': 20},
                {'company_id': tcs.id, 'job_title': 'Data Analyst',       'job_description': 'SQL and Python data analysis', 'eligibility_branch': 'Computer Science and Engineering',                       'min_cgpa': 7.5, 'eligibility_year': 4, 'salary': 7.0, 'status': 'approved', 'deadline_days': 15},
            ]
        if infosys:
            test_drives += [
                {'company_id': infosys.id, 'job_title': 'Systems Engineer',  'job_description': 'Infrastructure and systems role',  'eligibility_branch': 'Computer Science and Engineering,Information Technology,Electronics and Communication Engineering', 'min_cgpa': 6.0, 'eligibility_year': 4, 'salary': 6.5, 'status': 'approved', 'deadline_days': 25},
                {'company_id': infosys.id, 'job_title': 'Backend Developer', 'job_description': 'APIs and databases (drive closed)', 'eligibility_branch': 'Computer Science and Engineering,Information Technology',            'min_cgpa': 7.0, 'eligibility_year': 4, 'salary': 9.0, 'status': 'closed',   'deadline_days': 10},
                {'company_id': infosys.id, 'job_title': 'Cloud Intern',     'job_description': 'Cloud internship (awaiting admin)', 'eligibility_branch': 'Computer Science and Engineering,Information Technology,Electronics and Communication Engineering', 'min_cgpa': 6.5, 'eligibility_year': 3, 'salary': 4.0, 'status': 'pending',  'deadline_days': 30},
                {'company_id': infosys.id, 'job_title': 'QA Tester',        'job_description': 'Manual + automation testing (rejected)', 'eligibility_branch': 'Computer Science and Engineering,Information Technology',         'min_cgpa': 6.0, 'eligibility_year': 4, 'salary': 5.5, 'status': 'rejected', 'deadline_days': 12},
            ]

        created_drives = {}

        for d in test_drives:
            existing = PlacementDrive.query.filter_by(
                company_id=d['company_id'],
                job_title=d['job_title']
            ).first()
            if existing:
                created_drives[d['job_title']] = existing
                continue

            drive = PlacementDrive(
                company_id=d['company_id'],
                job_title=d['job_title'],
                job_description=d['job_description'],
                eligibility_branch=d['eligibility_branch'],
                min_cgpa=d['min_cgpa'],
                eligibility_year=d['eligibility_year'],
                salary=d['salary'],
                application_deadline=datetime.utcnow() + timedelta(days=d['deadline_days']),
                status=d['status']
            )
            db.session.add(drive)
            db.session.flush()
            created_drives[d['job_title']] = drive
            print(f"  Created drive: {d['job_title']} ({d['status']})")

        db.session.commit()

        # ─────────────────────────────────────────────
        # APPLICATIONS (8 applications, one per hiring stage)
        # Full chain: applied -> shortlisted -> interview -> offer -> placed / rejected.
        # Interview slots are only set once a candidate reaches 'interview' or later.
        # make_application returns the row (creating it if new, else the existing one)
        # so we can hand the 'placed' ones to make_placement below.
        # ─────────────────────────────────────────────
        def make_application(student_username, drive_title, status, feedback=None,
                             interview_start=None, interview_end=None, interview_mode=None):
            student = created_students.get(student_username)
            drive = created_drives.get(drive_title)
            if not student or not drive:
                return None

            existing = Application.query.filter_by(
                student_id=student.id,
                drive_id=drive.id
            ).first()
            if existing:
                return existing

            # local name is app_row (not 'app') so we never shadow the Flask app.
            app_row = Application(
                student_id=student.id,
                drive_id=drive.id,
                status=status,
                feedback=feedback,
                interview_start=interview_start,
                interview_end=interview_end,
                interview_mode=interview_mode
            )
            db.session.add(app_row)
            db.session.flush()  # assigns app_row.id, needed for a Placement FK
            print(f"  Application: {student_username} -> {drive_title} [{status}]")
            return app_row

        # A Placement is created for every 'placed' application, exactly the way
        # company.py does it: position + salary copied from the drive.
        def make_placement(application, joining_date=None):
            if not application:
                return
            existing = Placement.query.filter_by(application_id=application.id).first()
            if existing:
                return
            drive = PlacementDrive.query.get(application.drive_id)
            placement = Placement(
                application_id=application.id,
                student_id=application.student_id,
                company_id=drive.company_id,
                position=drive.job_title,
                salary=drive.salary,
                joining_date=joining_date
            )
            db.session.add(placement)
            print(f"  Placement: student_id={application.student_id} -> {drive.job_title}")

        # -- applied: just applied, nothing decided yet
        make_application('alice_s', 'Software Developer', 'applied')

        # -- shortlisted: picked, but no interview scheduled yet
        make_application('bob_k', 'Software Developer', 'shortlisted',
                         feedback='Cleared the aptitude round.')

        # -- interview: interview scheduled (future slots)
        cs, ce = interview_slot(3, 14)
        make_application('charlie_p', 'Software Developer', 'interview',
                         feedback='Technical interview scheduled.',
                         interview_start=cs, interview_end=ce, interview_mode='Online')

        ds, de = interview_slot(4, 11)
        make_application('diana_m', 'Systems Engineer', 'interview',
                         feedback='Interview scheduled.',
                         interview_start=ds, interview_end=de, interview_mode='In-person')

        # -- offer: interview done, offer extended
        es, ee = interview_slot(2, 10)
        make_application('evan_r', 'Software Developer', 'offer',
                         feedback='Strong interview; offer extended.',
                         interview_start=es, interview_end=ee, interview_mode='Online')

        # -- placed: interview happened in the past; a Placement will be created
        as_, ae = interview_slot(-5, 15)
        placed_alice = make_application('alice_s', 'Data Analyst', 'placed',
                                        feedback='Selected. Congratulations!',
                                        interview_start=as_, interview_end=ae, interview_mode='In-person')

        # -- rejected: did not make the cut
        make_application('bob_k', 'Data Analyst', 'rejected',
                         feedback='Did not meet the cut-off for this role.')

        # -- another placed (different company) so /admin/placements shows more than one
        chs, che = interview_slot(-6, 11)
        placed_charlie = make_application('charlie_p', 'Systems Engineer', 'placed',
                                          feedback='Selected for the role.',
                                          interview_start=chs, interview_end=che, interview_mode='Online')

        db.session.commit()

        # Create the Placement records for the two placed applications.
        make_placement(placed_alice,   joining_date=datetime.utcnow() + timedelta(days=30))
        make_placement(placed_charlie, joining_date=datetime.utcnow() + timedelta(days=45))
        db.session.commit()

        # ─────────────────────────────────────────────
        # SUMMARY
        # ─────────────────────────────────────────────
        print("=" * 60)
        print("SEEDING COMPLETE!")
        print("=" * 60)
        print("\n--- STUDENTS (password: test123) ---")
        print("  alice_s    | CS, CGPA 9.2  | applied + PLACED (Data Analyst)")
        print("  bob_k      | CS, CGPA 7.8  | shortlisted + rejected")
        print("  charlie_p  | IT, CGPA 8.5  | interview + PLACED (Systems Engineer)")
        print("  diana_m    | Electronics, CGPA 6.5 | interview")
        print("  evan_r     | CS, CGPA 8.9  | offer")
        print("  fiona_l    | Mechanical, CGPA 7.2  | BLACKLISTED (cannot log in)")
        print("\n--- COMPANIES (password: test123) ---")
        print("  tcs_hr     | TCS      | APPROVED  (2 drives)")
        print("  infosys_hr | Infosys  | APPROVED  (approved/closed/pending/rejected drives)")
        print("  google_hr  | Google   | PENDING   (no dashboard access yet)")
        print("  wipro_hr   | Wipro    | REJECTED")
        print("\n--- ADMIN ---")
        print("  admin      | admin123")
        print("\nStatuses covered: applied, shortlisted, interview, offer, placed, rejected")
        print("Placements created: 2 (Alice @ TCS Data Analyst, Charlie @ Infosys Systems Engineer)")
        print("=" * 60)


if __name__ == '__main__':
    seed_data()
