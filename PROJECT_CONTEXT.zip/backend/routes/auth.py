from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity, get_jwt
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, StudentProfile, CompanyProfile
from constants import BRANCHES
from functools import wraps

# Blueprint groups all auth-related routes under one name
auth_bp = Blueprint('auth', __name__)


# ─────────────────────────────────────────────
# BRANCH LIST (public — no JWT)
# The registration page needs this BEFORE the user logs in, so there is
# no @jwt_required here. Returns the canonical branch list from
# constants.py so the frontend dropdowns always match what the backend
# will accept during validation.
# ─────────────────────────────────────────────
@auth_bp.route('/branches', methods=['GET'])
def get_branches():
    return jsonify(BRANCHES), 200


# ─────────────────────────────────────────────
# STUDENT REGISTRATION
# ─────────────────────────────────────────────
@auth_bp.route('/register/student', methods=['POST'])
def register_student():
    data = request.get_json()

    # Check if username or email already exists
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username already exists'}), 400
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already exists'}), 400

    # Resolve the branch before creating anything:
    #   - "Others" path: the client sends a non-empty branch_other (custom text)
    #   - normal path: branch must be one of the canonical BRANCHES
    branch = (data.get('branch') or '').strip()
    branch_other = (data.get('branch_other') or '').strip()
    if branch_other:
        final_branch = branch_other
    elif branch in BRANCHES:
        final_branch = branch
    else:
        return jsonify({'message': 'Please select a valid branch'}), 400

    # Create the User row
    new_user = User(
        username=data['username'],
        email=data['email'],
        password=generate_password_hash(data['password']),
        role='student',
        is_active=True
    )
    db.session.add(new_user)
    db.session.flush()  # flush gets us the new_user.id before commit

    # Create the linked StudentProfile row
    new_student = StudentProfile(
        user_id=new_user.id,
        full_name=data['full_name'],
        branch=final_branch,
        cgpa=data.get('cgpa', 0.0),
        year=data.get('year', 1),
        phone=data.get('phone', ''),
        skills=data.get('skills', ''),
    )
    db.session.add(new_student)
    db.session.commit()

    return jsonify({'message': 'Student registered successfully'}), 201


# ─────────────────────────────────────────────
# COMPANY REGISTRATION
# ─────────────────────────────────────────────
@auth_bp.route('/register/company', methods=['POST'])
def register_company():
    data = request.get_json()

    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username already exists'}), 400
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already exists'}), 400

    new_user = User(
        username=data['username'],
        email=data['email'],
        password=generate_password_hash(data['password']),
        role='company',
        is_active=True
    )
    db.session.add(new_user)
    db.session.flush()

    new_company = CompanyProfile(
        user_id=new_user.id,
        company_name=data['company_name'],
        industry=data.get('industry', ''),
        location=data.get('location', ''),
        hr_contact=data.get('hr_contact', ''),
        website=data.get('website', ''),
        approval_status='pending'  # admin must approve before dashboard access
    )
    db.session.add(new_company)
    db.session.commit()

    return jsonify({'message': 'Company registered. Awaiting admin approval.'}), 201


# ─────────────────────────────────────────────
# LOGIN (works for admin, student, company)
# ─────────────────────────────────────────────
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()

    # Check if user exists and password matches
    if not user or not check_password_hash(user.password, data['password']):
        return jsonify({'message': 'Invalid username or password'}), 401

    # Block deactivated/blacklisted users
    if not user.is_active:
        return jsonify({'message': 'Account has been deactivated'}), 403

    # Create JWT token with user id as identity and role in additional claims
    token = create_access_token(
        identity=str(user.id),
        additional_claims={'role': user.role}
    )

    return jsonify({
        'access_token': token,
        'role': user.role,
        'username': user.username,
        'user_id': user.id
    }), 200


# ─────────────────────────────────────────────
# ROLE-BASED ACCESS DECORATOR
# Use this on any route to restrict by role
# Example: @role_required('admin')
# ─────────────────────────────────────────────
def role_required(required_role):
    def decorator(fn):
        @wraps(fn)
        @jwt_required()
        def wrapper(*args, **kwargs):
            claims = get_jwt()
            if claims.get('role') != required_role:
                return jsonify({'message': 'Access denied'}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


# ─────────────────────────────────────────────
# TEST ROUTE - verify token works
# ─────────────────────────────────────────────
@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def me():
    user_id = get_jwt_identity()
    claims = get_jwt()
    user = User.query.get(int(user_id))
    return jsonify({
        'id': user.id,
        'username': user.username,
        'role': claims.get('role'),
        'email': user.email
    }), 200
