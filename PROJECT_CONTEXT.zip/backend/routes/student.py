from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt, get_jwt_identity
from models import db, User, StudentProfile, CompanyProfile, PlacementDrive, Application, Placement
from constants import BRANCHES
from functools import wraps
from sqlalchemy.exc import IntegrityError

# Blueprint groups all student routes. It is registered in app.py
# with url_prefix='/student', so every route below sits under /student.
student_bp = Blueprint('student', __name__)


# ─────────────────────────────────────────────
# ROLE CHECK DECORATOR (student only)
# Same pattern as company_required in company.py:
# first @jwt_required() validates the token, then we read the
# 'role' claim and block anyone who is not a student.
# ─────────────────────────────────────────────
def student_required(fn):
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        claims = get_jwt()
        if claims.get('role') != 'student':
            return jsonify({'message': 'Student access required'}), 403
        return fn(*args, **kwargs)
    return wrapper


# ─────────────────────────────────────────────
# HELPER: get the StudentProfile of the logged-in user.
# The JWT identity is the user id stored as a STRING, so we
# cast it with int() (same as get_current_company in company.py).
# ─────────────────────────────────────────────
def get_current_student():
    user_id = int(get_jwt_identity())
    return StudentProfile.query.filter_by(user_id=user_id).first()


# ─────────────────────────────────────────────
# HELPER: check a student's eligibility for a drive.
# Returns two booleans: (cgpa_ok, branch_ok). Kept in one place
# so /drives (display) and /apply (enforcement) always agree.
# ─────────────────────────────────────────────
def check_eligibility(student, drive):
    # 1) CGPA: student's cgpa must be at least the drive's minimum.
    cgpa_ok = (student.cgpa or 0) >= (drive.min_cgpa or 0)

    # 2) Branch: eligibility_branch is a comma-separated string like
    #    "Computer Science,Information Technology". Split it, trim spaces,
    #    and compare case-insensitively so "computer science" still matches.
    allowed = [b.strip().lower() for b in (drive.eligibility_branch or '').split(',') if b.strip()]
    if not allowed:
        # No branches listed -> the drive is open to every branch.
        branch_ok = True
    else:
        branch_ok = (student.branch or '').strip().lower() in allowed

    return cgpa_ok, branch_ok


# ─────────────────────────────────────────────
# GET PROFILE
# Returns the logged-in student's own profile (plus username/email
# from the linked User row, handy for the dashboard header).
# ─────────────────────────────────────────────
@student_bp.route('/profile', methods=['GET'])
@student_required
def get_profile():
    student = get_current_student()
    if not student:
        return jsonify({'message': 'Student profile not found'}), 404

    user = User.query.get(student.user_id)
    return jsonify({
        'id': student.id,
        'username': user.username if user else '',
        'email': user.email if user else '',
        'full_name': student.full_name,
        'branch': student.branch,
        'cgpa': student.cgpa,
        'year': student.year,
        'skills': student.skills,
        'phone': student.phone,
        'resume_path': student.resume_path,
        'experience': student.experience
    }), 200


# ─────────────────────────────────────────────
# UPDATE PROFILE
# Updates the editable fields. Any field not sent in the request
# keeps its old value (data.get(field, current_value)).
# ─────────────────────────────────────────────
@student_bp.route('/profile', methods=['PUT'])
@student_required
def update_profile():
    student = get_current_student()
    if not student:
        return jsonify({'message': 'Student profile not found'}), 404

    data = request.get_json() or {}

    # Validate the branch the same way registration does:
    #   - "Others" path: a non-empty branch_other (custom text)
    #   - normal path: branch must be one of the canonical BRANCHES
    branch = (data.get('branch') or '').strip()
    branch_other = (data.get('branch_other') or '').strip()
    if branch_other:
        final_branch = branch_other
    elif branch in BRANCHES:
        final_branch = branch
    else:
        return jsonify({'message': 'Please select a valid branch'}), 400

    # Default to the existing value so a missing key never wipes data.
    student.full_name = data.get('full_name', student.full_name)
    student.branch    = final_branch
    student.cgpa      = data.get('cgpa',      student.cgpa)
    student.year      = data.get('year',      student.year)
    student.skills    = data.get('skills',    student.skills)
    student.phone     = data.get('phone',     student.phone)

    db.session.commit()
    return jsonify({'message': 'Profile updated successfully'}), 200


# ─────────────────────────────────────────────
# LIST APPROVED DRIVES
# Students only ever see drives the admin has approved.
# For each drive we add two booleans the frontend needs:
#   eligible        -> meets cgpa + branch requirements
#   already_applied -> this student already applied to it
# ─────────────────────────────────────────────
@student_bp.route('/drives', methods=['GET'])
@student_required
def get_drives():
    student = get_current_student()
    if not student:
        return jsonify({'message': 'Student profile not found'}), 404

    # All drive ids this student has applied to. We fetch them once and
    # use a set so the "already_applied" lookup below is a fast membership test.
    applied_ids = {a.drive_id for a in Application.query.filter_by(student_id=student.id).all()}

    drives = PlacementDrive.query.filter_by(status='approved').all()
    result = []
    for drive in drives:
        company = CompanyProfile.query.get(drive.company_id)
        cgpa_ok, branch_ok = check_eligibility(student, drive)
        result.append({
            'id': drive.id,
            'job_title': drive.job_title,
            'job_description': drive.job_description,
            'company_name': company.company_name if company else 'Unknown',
            'eligibility_branch': drive.eligibility_branch,
            'min_cgpa': drive.min_cgpa,
            'eligibility_year': drive.eligibility_year,
            'salary': drive.salary,
            'application_deadline': drive.application_deadline.isoformat() if drive.application_deadline else None,
            'eligible': cgpa_ok and branch_ok,
            'already_applied': drive.id in applied_ids
        })
    return jsonify(result), 200


# ─────────────────────────────────────────────
# APPLY TO A DRIVE
# Validates, in order:
#   1) drive exists
#   2) drive is approved (open for applications)
#   3) student is eligible (cgpa + branch) -> clear message per failure
#   4) not already applied (friendly check + DB unique constraint as backup)
# ─────────────────────────────────────────────
@student_bp.route('/apply/<int:drive_id>', methods=['POST'])
@student_required
def apply_to_drive(drive_id):
    student = get_current_student()
    if not student:
        return jsonify({'message': 'Student profile not found'}), 404

    drive = PlacementDrive.query.get(drive_id)
    if not drive:
        return jsonify({'message': 'Drive not found'}), 404

    # Only approved drives accept applications.
    if drive.status != 'approved':
        return jsonify({'message': 'This drive is not open for applications'}), 400

    # Eligibility: cgpa + branch, with a specific message for each failure.
    cgpa_ok, branch_ok = check_eligibility(student, drive)
    if not cgpa_ok:
        return jsonify({'message': f'Your CGPA ({student.cgpa}) is below the required minimum of {drive.min_cgpa}'}), 400
    if not branch_ok:
        return jsonify({'message': f'Your branch ({student.branch}) is not eligible for this drive'}), 400

    # Friendly pre-check so the normal case returns a clear message.
    existing = Application.query.filter_by(student_id=student.id, drive_id=drive.id).first()
    if existing:
        return jsonify({'message': 'You have already applied to this drive'}), 400

    # Create the application (starts in the 'applied' status).
    application = Application(
        student_id=student.id,
        drive_id=drive.id,
        status='applied'
    )
    db.session.add(application)

    # Safety net: the model has UNIQUE(student_id, drive_id). If two requests
    # race past the check above, the database itself rejects the duplicate.
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({'message': 'You have already applied to this drive'}), 400

    return jsonify({'message': 'Application submitted successfully'}), 201


# ─────────────────────────────────────────────
# APPLICATION HISTORY
# This student's applications, joined with drive + company info,
# plus status, dates, feedback, and the interview slot if one is set.
# ─────────────────────────────────────────────
@student_bp.route('/applications', methods=['GET'])
@student_required
def get_applications():
    student = get_current_student()
    if not student:
        return jsonify({'message': 'Student profile not found'}), 404

    applications = Application.query.filter_by(student_id=student.id).all()
    result = []
    for app in applications:
        drive = PlacementDrive.query.get(app.drive_id)
        company = CompanyProfile.query.get(drive.company_id) if drive else None
        result.append({
            'id': app.id,
            'drive_title': drive.job_title if drive else 'Unknown',
            'company_name': company.company_name if company else 'Unknown',
            'salary': drive.salary if drive else None,
            'status': app.status,
            'application_date': app.application_date.isoformat() if app.application_date else None,
            'feedback': app.feedback,
            'interview_start': app.interview_start.isoformat() if app.interview_start else None,
            'interview_end': app.interview_end.isoformat() if app.interview_end else None,
            'interview_mode': app.interview_mode
        })
    return jsonify(result), 200


# ─────────────────────────────────────────────
# PLACEMENT HISTORY
# The confirmed placements for THIS logged-in student.
# A Placement row is created by the company when it marks an
# application 'placed' (see update_application_status in company.py).
# We filter by student_id so a student only ever sees their own records.
# ─────────────────────────────────────────────
@student_bp.route('/placements', methods=['GET'])
@student_required
def get_placements():
    student = get_current_student()
    if not student:
        return jsonify({'message': 'Student profile not found'}), 404

    placements = Placement.query.filter_by(student_id=student.id).all()
    result = []
    for p in placements:
        company = CompanyProfile.query.get(p.company_id)
        result.append({
            'id': p.id,
            'position': p.position,
            'company_name': company.company_name if company else 'Unknown',
            'salary': p.salary,
            'joining_date': p.joining_date.isoformat() if p.joining_date else None,
            'date_created': p.date_created.isoformat() if p.date_created else None
        })
    return jsonify(result), 200
# ─────────────────────────────────────────────
# M7 CELERY ROUTES — TEMPORARILY DISABLED
# These two routes depend on Celery + Redis (see tasks.py / celery_app.py).
# They are commented out so the Flask app runs without a Celery worker or
# Redis broker. Re-enable them (remove the triple quotes) once Celery/Redis
# are set up. The import of `tasks` happens inside each function, so leaving
# these commented keeps app startup free of any Celery dependency.
# ─────────────────────────────────────────────
'''
# ─────────────────────────────────────────────
# TRIGGER CSV EXPORT (async)
# Student calls this from the dashboard.
# We immediately return the Celery task_id so the frontend
# can poll for completion without blocking the UI.
# ─────────────────────────────────────────────
@student_bp.route('/export-csv', methods=['POST'])
@student_required
def trigger_csv_export():
    from tasks import export_student_csv   # imported here to avoid circular import at module load

    student = get_current_student()
    if not student:
        return jsonify({'message': 'Student profile not found'}), 404

    # Fire the Celery task asynchronously and return the task ID
    task = export_student_csv.delay(student.id)
    return jsonify({
        'message': 'Export started. You will receive an email when it is ready.',
        'task_id': task.id
    }), 202


# ─────────────────────────────────────────────
# POLL EXPORT STATUS
# Frontend polls GET /student/export-status/<task_id> every few seconds.
# Celery stores the result in Redis backend under the task_id.
# Returns: pending | done | error
# ─────────────────────────────────────────────
@student_bp.route('/export-status/<task_id>', methods=['GET'])
@student_required
def export_status(task_id):
    from tasks import export_student_csv

    task = export_student_csv.AsyncResult(task_id)

    if task.state == 'PENDING':
        return jsonify({'status': 'pending'}), 200
    elif task.state == 'SUCCESS':
        return jsonify({'status': 'done', 'result': task.result}), 200
    else:
        return jsonify({'status': 'error', 'state': task.state}), 200
'''