from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt, get_jwt_identity
from models import db, User, StudentProfile, CompanyProfile, PlacementDrive, Application, Placement
from constants import BRANCHES
from functools import wraps
from datetime import datetime

company_bp = Blueprint('company', __name__)


# ─────────────────────────────────────────────
# ROLE CHECK DECORATOR (company only)
# Confirms the logged-in user has role 'company'
# ─────────────────────────────────────────────
def company_required(fn):
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        claims = get_jwt()
        if claims.get('role') != 'company':
            return jsonify({'message': 'Company access required'}), 403
        return fn(*args, **kwargs)
    return wrapper


# ─────────────────────────────────────────────
# HELPER: get the CompanyProfile of the logged-in user
# The JWT identity is the user id (stored as a string),
# so we convert it to int and look up the profile.
# ─────────────────────────────────────────────
def get_current_company():
    user_id = int(get_jwt_identity())
    return CompanyProfile.query.filter_by(user_id=user_id).first()


# ─────────────────────────────────────────────
# HELPER: all branch names available for a drive's eligibility.
# = the canonical BRANCHES list PLUS any custom branch that a student
#   already has in the DB (e.g. an "Others" branch typed at registration).
# This lets a company target real branches that exist in the system.
# Canonical branches come first (familiar order); extras are appended sorted.
# ─────────────────────────────────────────────
def get_all_branch_names():
    existing = [row[0] for row in db.session.query(StudentProfile.branch).distinct().all()]
    extras = sorted(b for b in set(existing) if b and b not in BRANCHES)
    return BRANCHES + extras


# ─────────────────────────────────────────────
# COMPANY PROFILE
# Returns the company's own profile + approval status.
# The frontend uses approval_status to decide whether
# to show the full dashboard or a "waiting for approval" message.
# ─────────────────────────────────────────────
@company_bp.route('/profile', methods=['GET'])
@company_required
def get_profile():
    company = get_current_company()
    if not company:
        return jsonify({'message': 'Company profile not found'}), 404

    return jsonify({
        'id': company.id,
        'company_name': company.company_name,
        'industry': company.industry,
        'location': company.location,
        'hr_contact': company.hr_contact,
        'website': company.website,
        'description': company.description,
        'approval_status': company.approval_status
    }), 200


# ─────────────────────────────────────────────
# COMPANY DASHBOARD STATS
# Counts for the dashboard cards:
#   - how many drives this company created
#   - how many applications it received in total
#   - how many of those are shortlisted
# ─────────────────────────────────────────────
@company_bp.route('/stats', methods=['GET'])
@company_required
def get_stats():
    company = get_current_company()
    if not company:
        return jsonify({'message': 'Company profile not found'}), 404

    drives = PlacementDrive.query.filter_by(company_id=company.id).all()
    drive_ids = [d.id for d in drives]

    total_applications = 0
    shortlisted = 0
    if drive_ids:
        total_applications = Application.query.filter(
            Application.drive_id.in_(drive_ids)
        ).count()
        shortlisted = Application.query.filter(
            Application.drive_id.in_(drive_ids),
            Application.status == 'shortlisted'
        ).count()

    return jsonify({
        'total_drives': len(drives),
        'total_applications': total_applications,
        'shortlisted': shortlisted
    }), 200


# ─────────────────────────────────────────────
# LIST OWN DRIVES
# Returns only the drives created by this company,
# with the number of applicants for each.
# ─────────────────────────────────────────────
@company_bp.route('/drives', methods=['GET'])
@company_required
def get_drives():
    company = get_current_company()
    if not company:
        return jsonify({'message': 'Company profile not found'}), 404

    drives = PlacementDrive.query.filter_by(company_id=company.id).all()
    result = []
    for drive in drives:
        applicant_count = Application.query.filter_by(drive_id=drive.id).count()
        result.append({
            'id': drive.id,
            'job_title': drive.job_title,
            'job_description': drive.job_description,
            'eligibility_branch': drive.eligibility_branch,
            'min_cgpa': drive.min_cgpa,
            'eligibility_year': drive.eligibility_year,
            'salary': drive.salary,
            'application_deadline': drive.application_deadline.isoformat() if drive.application_deadline else None,
            'status': drive.status,
            'applicant_count': applicant_count,
            'date_created': drive.date_created.isoformat()
        })
    return jsonify(result), 200


# ─────────────────────────────────────────────
# BRANCH LIST FOR DRIVE CREATION
# Returns every unique branch in the system (canonical + custom student
# branches). The Create Drive form uses this to build its checkbox list.
# ─────────────────────────────────────────────
@company_bp.route('/branches', methods=['GET'])
@company_required
def company_branches():
    return jsonify(get_all_branch_names()), 200


# ─────────────────────────────────────────────
# CREATE A NEW DRIVE
# Only an APPROVED company may create drives.
# New drives start with status 'pending' (admin must approve).
# ─────────────────────────────────────────────
@company_bp.route('/drive', methods=['POST'])
@company_required
def create_drive():
    company = get_current_company()
    if not company:
        return jsonify({'message': 'Company profile not found'}), 404

    # Block companies that are not yet approved by admin
    if company.approval_status != 'approved':
        return jsonify({'message': 'Your company must be approved before creating drives'}), 403

    data = request.get_json() or {}

    # Basic validation: job title is required
    if not data.get('job_title'):
        return jsonify({'message': 'Job title is required'}), 400

    # Parse the deadline if one was sent (expects YYYY-MM-DD)
    deadline = None
    if data.get('application_deadline'):
        try:
            deadline = datetime.strptime(data['application_deadline'], '%Y-%m-%d')
        except ValueError:
            return jsonify({'message': 'Deadline must be in YYYY-MM-DD format'}), 400

    # Validate eligibility branches.
    # An EMPTY value is allowed and means "open to all branches".
    # Otherwise every comma-separated branch must be a real branch in the
    # system (canonical list + custom student branches) — same set the
    # checkbox list is built from.
    allowed_branches = get_all_branch_names()
    eligibility_branch = data.get('eligibility_branch', '') or ''
    branch_parts = [b.strip() for b in eligibility_branch.split(',') if b.strip()]
    for b in branch_parts:
        if b not in allowed_branches:
            return jsonify({'message': f'Invalid branch: {b}'}), 400
    # Store a cleaned, comma-joined string (drops stray spaces/empty items).
    eligibility_branch = ','.join(branch_parts)

    drive = PlacementDrive(
        company_id=company.id,
        job_title=data['job_title'],
        job_description=data.get('job_description', ''),
        eligibility_branch=eligibility_branch,
        min_cgpa=data.get('min_cgpa', 0.0),
        eligibility_year=data.get('eligibility_year'),
        salary=data.get('salary'),
        application_deadline=deadline,
        status='pending'  # waits for admin approval
    )
    db.session.add(drive)
    db.session.commit()

    return jsonify({'message': 'Drive created. Awaiting admin approval.', 'drive_id': drive.id}), 201


# ─────────────────────────────────────────────
# CLOSE A DRIVE
# Company can close its own drive (stops new applications).
# We check the drive belongs to this company before changing it.
# ─────────────────────────────────────────────
@company_bp.route('/drive/<int:drive_id>/close', methods=['PUT'])
@company_required
def close_drive(drive_id):
    company = get_current_company()
    drive = PlacementDrive.query.get(drive_id)

    if not drive or drive.company_id != company.id:
        return jsonify({'message': 'Drive not found'}), 404

    drive.status = 'closed'
    db.session.commit()
    return jsonify({'message': 'Drive closed successfully'}), 200


# ─────────────────────────────────────────────
# VIEW APPLICANTS FOR A DRIVE
# Lists every student who applied to one specific drive.
# Again we verify the drive belongs to this company.
# ─────────────────────────────────────────────
@company_bp.route('/drive/<int:drive_id>/applications', methods=['GET'])
@company_required
def get_drive_applications(drive_id):
    company = get_current_company()
    drive = PlacementDrive.query.get(drive_id)

    if not drive or drive.company_id != company.id:
        return jsonify({'message': 'Drive not found'}), 404

    applications = Application.query.filter_by(drive_id=drive_id).all()
    result = []
    for app in applications:
        student = StudentProfile.query.get(app.student_id)
        result.append({
            'id': app.id,
            'student_id': app.student_id,
            'student_name': student.full_name if student else 'Unknown',
            'branch': student.branch if student else '',
            'cgpa': student.cgpa if student else 0,
            'skills': student.skills if student else '',
            'resume_path': student.resume_path if student else None,
            'application_date': app.application_date.isoformat(),
            'status': app.status,
            'feedback': app.feedback,
            'interview_start': app.interview_start.isoformat() if app.interview_start else None,
            'interview_end': app.interview_end.isoformat() if app.interview_end else None,
            'interview_mode': app.interview_mode
        })
    return jsonify(result), 200


# ─────────────────────────────────────────────
# UPDATE APPLICATION STATUS
# Company moves an application along the hiring chain:
#   applied -> shortlisted -> interview -> offer -> placed / rejected
# 'placed' and 'rejected' are FINAL states and cannot be changed again.
# When an application reaches 'placed', we also create a Placement record.
# We make sure the application belongs to one of THIS company's drives.
# ─────────────────────────────────────────────
@company_bp.route('/application/<int:app_id>/status', methods=['PUT'])
@company_required
def update_application_status(app_id):
    company = get_current_company()
    application = Application.query.get(app_id)
    if not application:
        return jsonify({'message': 'Application not found'}), 404

    # Ownership check: the drive of this application must be this company's
    drive = PlacementDrive.query.get(application.drive_id)
    if not drive or drive.company_id != company.id:
        return jsonify({'message': 'Not allowed'}), 403

    # Final states are locked: once placed or rejected, nothing can change it.
    if application.status in ('placed', 'rejected'):
        return jsonify({'message': f'Application is already {application.status} and cannot be changed'}), 400

    data = request.get_json() or {}
    new_status = data.get('status')

    allowed = ['applied', 'shortlisted', 'interview', 'offer', 'placed', 'rejected']
    if new_status not in allowed:
        return jsonify({'message': f'Status must be one of {allowed}'}), 400

    # When the student is being placed, create the matching Placement record.
    # We add it to the session now so it saves together with the status change.
    if new_status == 'placed':
        # Don't create a second Placement if this endpoint is somehow called twice.
        existing_placement = Placement.query.filter_by(application_id=application.id).first()
        if not existing_placement:
            # Salary: use the value sent in the request if given, else the drive's salary.
            salary = data.get('salary', drive.salary)

            # Joining date is optional. If sent, it must be in YYYY-MM-DD format.
            joining_date = None
            if data.get('joining_date'):
                try:
                    joining_date = datetime.strptime(data['joining_date'], '%Y-%m-%d')
                except ValueError:
                    return jsonify({'message': 'joining_date must be in YYYY-MM-DD format'}), 400

            placement = Placement(
                application_id=application.id,
                student_id=application.student_id,
                company_id=drive.company_id,
                position=drive.job_title,
                salary=salary,
                joining_date=joining_date
            )
            db.session.add(placement)

    application.status = new_status
    if 'feedback' in data:
        application.feedback = data['feedback']

    db.session.commit()
    return jsonify({'message': f'Application marked as {new_status}'}), 200


# ─────────────────────────────────────────────
# SCHEDULE AN INTERVIEW
# Sets interview date + mode on a shortlisted application.
# ─────────────────────────────────────────────
@company_bp.route('/application/<int:app_id>/interview', methods=['PUT'])
@company_required
def schedule_interview(app_id):
    company = get_current_company()
    application = Application.query.get(app_id)
    if not application:
        return jsonify({'message': 'Application not found'}), 404

    drive = PlacementDrive.query.get(application.drive_id)
    if not drive or drive.company_id != company.id:
        return jsonify({'message': 'Not allowed'}), 403

    data = request.get_json() or {}

    if not data.get('interview_start') or not data.get('interview_end'):
        return jsonify({'message': 'interview_start and interview_end are required'}), 400

    try:
        # Replace the T with a space and add seconds if missing
        # This handles "2026-06-29T14:30" → "2026-06-29 14:30:00"
        start_raw = data['interview_start'].replace('T', ' ')
        end_raw   = data['interview_end'].replace('T', ' ')

        # Add seconds if not present (length check: "2026-06-29 14:30" = 16 chars)
        if len(start_raw) == 16:
            start_raw = start_raw + ':00'
        if len(end_raw) == 16:
            end_raw = end_raw + ':00'

        application.interview_start = datetime.strptime(start_raw, '%Y-%m-%d %H:%M:%S')
        application.interview_end   = datetime.strptime(end_raw,   '%Y-%m-%d %H:%M:%S')
        application.interview_mode  = data.get('interview_mode', 'In-person')

    except ValueError as e:
        return jsonify({'message': f'Invalid date format: {str(e)}'}), 400

    # Scheduling an interview IS what advances a shortlisted application to the
    # 'interview' stage. There is no separate "move to interview" button.
    if application.status == 'shortlisted':
        application.status = 'interview'

    db.session.commit()
    return jsonify({'message': 'Interview scheduled successfully'}), 200

# ─────────────────────────────────────────────
# REOPEN A DRIVE
# Company can reopen a closed drive.
# Status goes back to 'pending' — admin must approve again.
# This prevents companies from bypassing admin approval
# by closing and reopening drives freely.
# ─────────────────────────────────────────────
@company_bp.route('/drive/<int:drive_id>/reopen', methods=['PUT'])
@company_required
def reopen_drive(drive_id):
    company = get_current_company()
    drive = PlacementDrive.query.get(drive_id)

    # Make sure the drive exists and belongs to THIS company
    if not drive or drive.company_id != company.id:
        return jsonify({'message': 'Drive not found'}), 404

    # Only closed drives can be reopened
    if drive.status != 'closed':
        return jsonify({'message': 'Only closed drives can be reopened'}), 400

    # Goes back to pending — admin must approve again
    drive.status = 'pending'
    db.session.commit()
    return jsonify({'message': 'Drive reopened. Awaiting admin approval again.'}), 200