from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt
from models import db, User, StudentProfile, CompanyProfile, PlacementDrive, Application, Placement
from functools import wraps

admin_bp = Blueprint('admin', __name__)

# ─────────────────────────────────────────────
# ROLE CHECK DECORATOR (admin only)
# ─────────────────────────────────────────────
def admin_required(fn):
    @wraps(fn)
    @jwt_required()
    def wrapper(*args, **kwargs):
        claims = get_jwt()
        if claims.get('role') != 'admin':
            return jsonify({'message': 'Admin access required'}), 403
        return fn(*args, **kwargs)
    return wrapper


# ─────────────────────────────────────────────
# DASHBOARD STATS
# ─────────────────────────────────────────────
@admin_bp.route('/stats', methods=['GET'])
@admin_required
def get_stats():
    total_students = StudentProfile.query.count()
    total_companies = CompanyProfile.query.count()
    total_drives = PlacementDrive.query.count()
    total_applications = Application.query.count()
    
    return jsonify({
        'total_students': total_students,
        'total_companies': total_companies,
        'total_drives': total_drives,
        'total_applications': total_applications
    }), 200


# ─────────────────────────────────────────────
# COMPANY MANAGEMENT
# ─────────────────────────────────────────────
@admin_bp.route('/companies', methods=['GET'])
@admin_required
def get_companies():
    companies = CompanyProfile.query.all()
    result = []
    for company in companies:
        user = User.query.get(company.user_id)
        result.append({
            'id': company.id,
            'user_id': user.id,
            'company_name': company.company_name,
            'industry': company.industry,
            'location': company.location,
            'hr_contact': company.hr_contact,
            'website': company.website,
            'approval_status': company.approval_status,
            'is_active': user.is_active,
            'email': user.email
        })
    return jsonify(result), 200


@admin_bp.route('/company/<int:company_id>/approve', methods=['PUT'])
@admin_required
def approve_company(company_id):
    company = CompanyProfile.query.get(company_id)
    if not company:
        return jsonify({'message': 'Company not found'}), 404
    
    company.approval_status = 'approved'
    db.session.commit()
    return jsonify({'message': 'Company approved successfully'}), 200


@admin_bp.route('/company/<int:company_id>/reject', methods=['PUT'])
@admin_required
def reject_company(company_id):
    company = CompanyProfile.query.get(company_id)
    if not company:
        return jsonify({'message': 'Company not found'}), 404
    
    company.approval_status = 'rejected'
    db.session.commit()
    return jsonify({'message': 'Company rejected'}), 200


@admin_bp.route('/company/<int:user_id>/toggle-active', methods=['PUT'])
@admin_required
def toggle_company_active(user_id):
    user = User.query.get(user_id)
    if not user or user.role != 'company':
        return jsonify({'message': 'Company user not found'}), 404
    
    user.is_active = not user.is_active
    db.session.commit()
    status = 'activated' if user.is_active else 'deactivated'
    return jsonify({'message': f'Company {status} successfully', 'is_active': user.is_active}), 200


# ─────────────────────────────────────────────
# STUDENT MANAGEMENT
# ─────────────────────────────────────────────
@admin_bp.route('/students', methods=['GET'])
@admin_required
def get_students():
    students = StudentProfile.query.all()
    result = []
    for student in students:
        user = User.query.get(student.user_id)
        result.append({
            'id': student.id,
            'user_id': user.id,
            'full_name': student.full_name,
            'branch': student.branch,
            'cgpa': student.cgpa,
            'year': student.year,
            'skills': student.skills,
            'email': user.email,
            'username': user.username,
            'is_active': user.is_active
        })
    return jsonify(result), 200


@admin_bp.route('/student/<int:user_id>/toggle-active', methods=['PUT'])
@admin_required
def toggle_student_active(user_id):
    user = User.query.get(user_id)
    if not user or user.role != 'student':
        return jsonify({'message': 'Student user not found'}), 404
    
    user.is_active = not user.is_active
    db.session.commit()
    status = 'activated' if user.is_active else 'blacklisted'
    return jsonify({'message': f'Student {status} successfully', 'is_active': user.is_active}), 200


# ─────────────────────────────────────────────
# PLACEMENT DRIVE MANAGEMENT
# ─────────────────────────────────────────────
@admin_bp.route('/drives', methods=['GET'])
@admin_required
def get_drives():
    drives = PlacementDrive.query.all()
    result = []
    for drive in drives:
        company = CompanyProfile.query.get(drive.company_id)
        result.append({
            'id': drive.id,
            'company_id': drive.company_id,
            'company_name': company.company_name if company else 'Unknown',
            'job_title': drive.job_title,
            'job_description': drive.job_description,
            'eligibility_branch': drive.eligibility_branch,
            'min_cgpa': drive.min_cgpa,
            'eligibility_year': drive.eligibility_year,
            'salary': drive.salary,
            'application_deadline': drive.application_deadline.isoformat() if drive.application_deadline else None,
            'status': drive.status,
            'date_created': drive.date_created.isoformat()
        })
    return jsonify(result), 200


@admin_bp.route('/drive/<int:drive_id>/approve', methods=['PUT'])
@admin_required
def approve_drive(drive_id):
    drive = PlacementDrive.query.get(drive_id)
    if not drive:
        return jsonify({'message': 'Drive not found'}), 404
    
    drive.status = 'approved'
    db.session.commit()
    return jsonify({'message': 'Drive approved successfully'}), 200


@admin_bp.route('/drive/<int:drive_id>/reject', methods=['PUT'])
@admin_required
def reject_drive(drive_id):
    drive = PlacementDrive.query.get(drive_id)
    if not drive:
        return jsonify({'message': 'Drive not found'}), 404
    
    drive.status = 'rejected'
    db.session.commit()
    return jsonify({'message': 'Drive rejected'}), 200


@admin_bp.route('/drive/<int:drive_id>/close', methods=['PUT'])
@admin_required
def close_drive(drive_id):
    drive = PlacementDrive.query.get(drive_id)
    if not drive:
        return jsonify({'message': 'Drive not found'}), 404
    
    drive.status = 'closed'
    db.session.commit()
    return jsonify({'message': 'Drive closed successfully'}), 200


# ─────────────────────────────────────────────
# APPLICATION MANAGEMENT
# ─────────────────────────────────────────────
@admin_bp.route('/applications', methods=['GET'])
@admin_required
def get_applications():
    applications = Application.query.all()
    result = []
    for app in applications:
        student = StudentProfile.query.get(app.student_id)
        drive = PlacementDrive.query.get(app.drive_id)
        company = CompanyProfile.query.get(drive.company_id) if drive else None
        
        result.append({
            'id': app.id,
            'student_id': app.student_id,
            'student_name': student.full_name if student else 'Unknown',
            'drive_id': app.drive_id,
            'drive_title': drive.job_title if drive else 'Unknown',
            'company_name': company.company_name if company else 'Unknown',
            'application_date': app.application_date.isoformat(),
            'status': app.status,
            'feedback': app.feedback
        })
    return jsonify(result), 200


# ─────────────────────────────────────────────
# PLACEMENT RECORDS (institute-wide)
# Every confirmed placement across all students and companies.
# Admin-only view of who has been placed where.
# ─────────────────────────────────────────────
@admin_bp.route('/placements', methods=['GET'])
@admin_required
def get_placements():
    placements = Placement.query.all()
    result = []
    for p in placements:
        student = StudentProfile.query.get(p.student_id)
        company = CompanyProfile.query.get(p.company_id)
        result.append({
            'id': p.id,
            'student_name': student.full_name if student else 'Unknown',
            'company_name': company.company_name if company else 'Unknown',
            'position': p.position,
            'salary': p.salary,
            'joining_date': p.joining_date.isoformat() if p.joining_date else None,
            'date_created': p.date_created.isoformat() if p.date_created else None
        })
    return jsonify(result), 200


# ─────────────────────────────────────────────
# SEARCH FUNCTIONALITY
# ─────────────────────────────────────────────
@admin_bp.route('/search/companies', methods=['GET'])
@admin_required
def search_companies():
    query = request.args.get('q', '').lower()
    if not query:
        return jsonify([]), 200
    
    companies = CompanyProfile.query.filter(
        db.or_(
            CompanyProfile.company_name.ilike(f'%{query}%'),
            CompanyProfile.industry.ilike(f'%{query}%'),
            CompanyProfile.location.ilike(f'%{query}%')
        )
    ).all()
    
    result = []
    for company in companies:
        user = User.query.get(company.user_id)
        result.append({
            'id': company.id,
            'user_id': user.id,
            'company_name': company.company_name,
            'industry': company.industry,
            'location': company.location,
            'approval_status': company.approval_status,
            'is_active': user.is_active
        })
    return jsonify(result), 200


@admin_bp.route('/search/students', methods=['GET'])
@admin_required
def search_students():
    query = request.args.get('q', '').lower()
    if not query:
        return jsonify([]), 200
    
    students = StudentProfile.query.filter(
        db.or_(
            StudentProfile.full_name.ilike(f'%{query}%'),
            StudentProfile.branch.ilike(f'%{query}%')
        )
    ).all()
    
    result = []
    for student in students:
        user = User.query.get(student.user_id)
        if user and (query in user.username.lower() or query in student.full_name.lower() or query in student.branch.lower()):
            result.append({
                'id': student.id,
                'user_id': user.id,
                'full_name': student.full_name,
                'branch': student.branch,
                'cgpa': student.cgpa,
                'year': student.year,
                'username': user.username,
                'is_active': user.is_active
            })
    return jsonify(result), 200