# ─────────────────────────────────────────────
# CANONICAL BRANCH LIST — single source of truth
# The /branches API, student registration/profile validation, and
# drive eligibility validation all import BRANCHES from here, so the
# allowed values can never drift apart across the app.
# Edit this list to add/remove branches everywhere at once.
# ─────────────────────────────────────────────
BRANCHES = [
    'Computer Science and Engineering',
    'Information Technology',
    'Electronics and Communication Engineering',
    'Electrical and Electronics Engineering',
    'Mechanical Engineering',
    'Civil Engineering',
    'Chemical Engineering',
    'Data Science',
    'Biotechnology',
    'Aerospace Engineering',
]
