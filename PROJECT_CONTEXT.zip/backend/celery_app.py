from celery import Celery
from celery.schedules import crontab


def make_celery(flask_app):
    """
    Creates and returns a Celery instance bound to the Flask app.

    ContextTask ensures every Celery task runs inside Flask's application
    context — so db.session, models, and app.config are all available
    inside task functions without any extra setup.
    """
    celery = Celery(
        flask_app.import_name,
        broker=flask_app.config['CELERY_BROKER_URL'],
        backend=flask_app.config['CELERY_RESULT_BACKEND']
    )
    celery.conf.update(flask_app.config)

    # ── Celery Beat periodic schedule ──────────────────────────────────
    celery.conf.beat_schedule = {

        # Job 1: Daily reminder — every day at 8:00 AM UTC
        'daily-deadline-reminder': {
            'task': 'tasks.send_daily_reminders',
            'schedule': crontab(hour=8, minute=0),
        },

        # Job 2: Monthly report — 1st of every month at 7:00 AM UTC
        'monthly-placement-report': {
            'task': 'tasks.send_monthly_report',
            'schedule': crontab(day_of_month=1, hour=7, minute=0),
        },
    }
    celery.conf.timezone = 'UTC'

    class ContextTask(celery.Task):
        """Wraps every task call inside Flask's app context."""
        def __call__(self, *args, **kwargs):
            with flask_app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery