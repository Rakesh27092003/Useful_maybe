from flask import Flask
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from models import db
from datetime import timedelta


app = Flask(__name__)

# ── Database ──────────────────────────────────────────────────────────
app.config['SQLALCHEMY_DATABASE_URI']        = 'sqlite:///placement.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# ── Security ──────────────────────────────────────────────────────────
app.config['SECRET_KEY']     = 'your-secret-key-change-later'
app.config['JWT_SECRET_KEY'] = 'your-jwt-secret-key-change-later'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=6)

# ── Celery + Redis ────────────────────────────────────────────────────
# Redis must be running locally on port 6379 before starting the worker.
app.config['CELERY_BROKER_URL']    = 'redis://localhost:6379/0'
app.config['CELERY_RESULT_BACKEND'] = 'redis://localhost:6379/0'

# ── Email (SMTP) ──────────────────────────────────────────────────────
# Use your Gmail address + an App Password (not your normal Gmail password).
# To create an App Password: Google Account → Security → 2-Step Verification
# → App Passwords → create one for "Mail".
app.config['MAIL_SERVER']   = 'smtp.gmail.com'
app.config['MAIL_PORT']     = 587
app.config['MAIL_USERNAME'] = 'rakesh27092003@gmail.com'   # ← change this
app.config['MAIL_PASSWORD'] = 'mlkuhjovihtxlfyt' #← change this

# ── Extensions ────────────────────────────────────────────────────────
db.init_app(app)
JWTManager(app)
CORS(app)

# ── Blueprints ────────────────────────────────────────────────────────
from routes.auth    import auth_bp
from routes.admin   import admin_bp
from routes.company import company_bp
from routes.student import student_bp

app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp,   url_prefix='/admin')
app.register_blueprint(company_bp, url_prefix='/company')
app.register_blueprint(student_bp, url_prefix='/student')


@app.route('/')
def home():
    return 'Placement Portal API is running'


if __name__ == '__main__':
    app.run(debug=True)