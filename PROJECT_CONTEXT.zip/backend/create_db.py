from app import app
from models import db, User
from werkzeug.security import generate_password_hash


def create_database():
    with app.app_context():
        # Create all tables defined in models.py
        db.create_all()
        print("All tables created successfully.")

        # Check if admin already exists
        existing_admin = User.query.filter_by(role='admin').first()
        if existing_admin:
            print("Admin already exists. Skipping.")
            return

        # Create the admin user
        admin = User(
            username='admin',
            email='rakesh27092003@gmail.com',
            password=generate_password_hash('admin123'),
            role='admin',
            is_active=True
        )
        db.session.add(admin)
        db.session.commit()
        print("Admin user created.")
        print("Username: admin")
        print("Password: admin123")


if __name__ == '__main__':
    create_database()