import csv
import io
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta

from app import app
from celery_app import make_celery

# Celery instance — workers import this module, so celery must be
# created here (not in app.py) to avoid circular imports.
celery = make_celery(app)


# ─────────────────────────────────────────────
# HELPER: send an email via SMTP
# Uses app.config for server / credentials.
# attachment_csv: optional CSV string to attach.
# ─────────────────────────────────────────────
def send_email(to_address, subject, body_html,
               attachment_csv=None, attachment_filename=None):
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From']    = app.config['MAIL_USERNAME']
    msg['To']      = to_address

    msg.attach(MIMEText(body_html, 'html'))

    # Attach CSV file if provided
    if attachment_csv and attachment_filename:
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment_csv.encode('utf-8'))
        encoders.encode_base64(part)
        part.add_header(
            'Content-Disposition',
            f'attachment; filename="{attachment_filename}"'
        )
        msg.attach(part)

    try:
        with smtplib.SMTP(app.config['MAIL_SERVER'], app.config['MAIL_PORT']) as server:
            server.ehlo()
            server.starttls()
            server.login(app.config['MAIL_USERNAME'], app.config['MAIL_PASSWORD'])
            server.sendmail(app.config['MAIL_USERNAME'], to_address, msg.as_string())
        print(f'[EMAIL] Sent "{subject}" to {to_address}')
    except Exception as e:
        print(f'[EMAIL ERROR] Failed to send to {to_address}: {e}')


# ─────────────────────────────────────────────
# JOB 1: DAILY DEADLINE REMINDERS (Celery Beat)
# Runs every day at 8 AM.
# Finds approved drives whose deadline is within the next 3 days.
# Emails each active student who has NOT yet applied to those drives.
# ─────────────────────────────────────────────
@celery.task(name='tasks.send_daily_reminders')
def send_daily_reminders():
    from models import PlacementDrive, Application, StudentProfile, User

    today = datetime.utcnow()
    three_days_later = today + timedelta(days=3)

    # Drives that are open and close within the next 3 days
    upcoming = PlacementDrive.query.filter(
        PlacementDrive.status == 'approved',
        PlacementDrive.application_deadline >= today,
        PlacementDrive.application_deadline <= three_days_later
    ).all()

    if not upcoming:
        print('[REMINDER] No deadlines in the next 3 days. Nothing to send.')
        return

    students = StudentProfile.query.all()

    for student in students:
        user = User.query.get(student.user_id)
        if not user or not user.is_active or not user.email:
            continue

        # Drives this student has already applied to
        applied_ids = {
            a.drive_id for a in
            Application.query.filter_by(student_id=student.id).all()
        }

        # Only remind about drives they haven't applied to yet
        pending_drives = [d for d in upcoming if d.id not in applied_ids]
        if not pending_drives:
            continue

        # Build the drive list for the email body
        drive_rows = ''.join([
            f"<tr>"
            f"<td>{d.job_title}</td>"
            f"<td>{d.application_deadline.strftime('%Y-%m-%d')}</td>"
            f"</tr>"
            for d in pending_drives
        ])

        body = f"""
        <h3 style="color:#667eea;">Placement Portal — Deadline Reminder</h3>
        <p>Hi <strong>{student.full_name}</strong>,</p>
        <p>The following drives are closing in the next 3 days.
           Log in now to apply before they close:</p>
        <table border="1" cellpadding="8" cellspacing="0"
               style="border-collapse:collapse; width:100%;">
            <tr style="background:#667eea; color:#fff;">
                <th>Drive</th><th>Deadline</th>
            </tr>
            {drive_rows}
        </table>
        <br>
        <p>— Placement Cell, IITM</p>
        """

        send_email(user.email, '⏰ Upcoming Placement Deadlines', body)


# ─────────────────────────────────────────────
# JOB 2: MONTHLY ACTIVITY REPORT (Celery Beat)
# Runs on the 1st of every month at 7 AM.
# Summarises last month's activity and emails the admin.
# ─────────────────────────────────────────────
@celery.task(name='tasks.send_monthly_report')
def send_monthly_report():
    from models import PlacementDrive, Application, Placement, User

    today = datetime.utcnow()

    # Date range: 1st of last month → 1st of this month
    first_this_month = today.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if first_this_month.month == 1:
        first_last_month = first_this_month.replace(
            year=first_this_month.year - 1, month=12
        )
    else:
        first_last_month = first_this_month.replace(
            month=first_this_month.month - 1
        )

    month_label = first_last_month.strftime('%B %Y')

    # Count activity in the last month
    drives_count = PlacementDrive.query.filter(
        PlacementDrive.date_created >= first_last_month,
        PlacementDrive.date_created < first_this_month
    ).count()

    apps_count = Application.query.filter(
        Application.application_date >= first_last_month,
        Application.application_date < first_this_month
    ).count()

    placed_count = Placement.query.filter(
        Placement.date_created >= first_last_month,
        Placement.date_created < first_this_month
    ).count()

    body = f"""
    <h2 style="color:#667eea;">Monthly Placement Activity Report</h2>
    <h4>{month_label}</h4>
    <table border="1" cellpadding="10" cellspacing="0"
           style="border-collapse:collapse; width:60%;">
        <tr style="background:#667eea; color:#fff;">
            <th>Metric</th><th>Count</th>
        </tr>
        <tr><td>Placement Drives Conducted</td><td>{drives_count}</td></tr>
        <tr><td>Total Applications Submitted</td><td>{apps_count}</td></tr>
        <tr><td>Students Confirmed Placed</td><td>{placed_count}</td></tr>
    </table>
    <br>
    <p style="color:#888; font-size:0.85rem;">
        Auto-generated on {today.strftime('%Y-%m-%d')} by the Placement Portal.
    </p>
    """

    admin = User.query.filter_by(role='admin').first()
    if not admin:
        print('[REPORT] Admin user not found, cannot send report.')
        return

    send_email(admin.email, f'📊 Monthly Report — {month_label}', body)


# ─────────────────────────────────────────────
# JOB 3: STUDENT-TRIGGERED CSV EXPORT (async)
# Called from /student/export-csv endpoint.
# bind=True gives the task access to self.request.id (the task ID)
# which the frontend polls to check completion.
# Generates a CSV of the student's full application history,
# emails it to them, and returns a status dict.
# ─────────────────────────────────────────────
@celery.task(name='tasks.export_student_csv', bind=True)
def export_student_csv(self, student_id):
    from models import Application, PlacementDrive, CompanyProfile, StudentProfile, User

    student = StudentProfile.query.get(student_id)
    if not student:
        return {'status': 'error', 'message': 'Student not found'}

    user = User.query.get(student.user_id)
    applications = Application.query.filter_by(student_id=student.id).all()

    # Build CSV entirely in memory — no disk I/O needed
    output = io.StringIO()
    writer = csv.writer(output)

    # Header row (matches the spec exactly)
    writer.writerow([
        'Student ID', 'Student Name', 'Company Name',
        'Drive Title', 'Application Status',
        'Application Date', 'Interview Date', 'Feedback'
    ])

    for app in applications:
        drive   = PlacementDrive.query.get(app.drive_id)
        company = CompanyProfile.query.get(drive.company_id) if drive else None
        writer.writerow([
            student.id,
            student.full_name,
            company.company_name if company else 'N/A',
            drive.job_title     if drive   else 'N/A',
            app.status,
            app.application_date.strftime('%Y-%m-%d') if app.application_date else 'N/A',
            app.interview_start.strftime('%Y-%m-%d %H:%M') if app.interview_start else 'N/A',
            app.feedback or 'N/A'
        ])

    csv_content = output.getvalue()
    filename = (
        f"applications_{student.full_name.replace(' ', '_')}"
        f"_{datetime.utcnow().strftime('%Y%m%d')}.csv"
    )

    body = f"""
    <h3 style="color:#667eea;">Your Application Export is Ready</h3>
    <p>Hi <strong>{student.full_name}</strong>,</p>
    <p>Your placement application history has been exported.
       Please find the CSV file attached to this email.</p>
    <p>— Placement Portal</p>
    """

    send_email(
        user.email,
        '📁 Your Application History Export',
        body,
        attachment_csv=csv_content,
        attachment_filename=filename
    )

    return {'status': 'done', 'email': user.email}