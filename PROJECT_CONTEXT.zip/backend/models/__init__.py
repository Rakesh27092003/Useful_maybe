from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

# USER (unified table for all roles)
# role values: 'admin' | 'company' | 'student'
class User(db.Model):
    __tablename__ = 'users'

    id           = db.Column(db.Integer, primary_key=True)
    username     = db.Column(db.String(100), nullable=False, unique=True)
    email        = db.Column(db.String(150), nullable=False, unique=True)
    password     = db.Column(db.String(200), nullable=False)
    role         = db.Column(db.String(20),  nullable=False)
    is_active    = db.Column(db.Boolean, default=True)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    student_profile = db.relationship('StudentProfile', backref='user', uselist=False)
    company_profile = db.relationship('CompanyProfile', backref='user', uselist=False)

    def __repr__(self):
        return f'<User {self.username} | {self.role}>'

    def as_dict(self):
        return {c.key: getattr(self, c.key) for c in self.__table__.columns}


# STUDENT PROFILE (linked 1:1 to User)
class StudentProfile(db.Model):
    __tablename__ = 'student_profiles'

    id          = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    full_name   = db.Column(db.String(100), nullable=False)
    branch      = db.Column(db.String(100), nullable=False)
    cgpa        = db.Column(db.Float, nullable=False, default=0.0)
    year        = db.Column(db.Integer, nullable=False, default=1)
    skills      = db.Column(db.String(300), nullable=True)
    resume_path = db.Column(db.String(200), nullable=True)
    experience  = db.Column(db.String(200), nullable=True)
    phone       = db.Column(db.String(20),  nullable=True)

    applications = db.relationship('Application', backref='student', lazy=True)
    placements   = db.relationship('Placement', backref='student', lazy=True)

    def __repr__(self):
        return f'<StudentProfile {self.full_name} | {self.branch}>'

    def as_dict(self):
        return {c.key: getattr(self, c.key) for c in self.__table__.columns}


# COMPANY PROFILE (linked 1:1 to User)
class CompanyProfile(db.Model):
    __tablename__ = 'company_profiles'

    id              = db.Column(db.Integer, primary_key=True)
    user_id         = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    company_name    = db.Column(db.String(150), nullable=False)
    industry        = db.Column(db.String(100), nullable=True)
    location        = db.Column(db.String(150), nullable=True)
    hr_contact      = db.Column(db.String(100), nullable=True)
    website         = db.Column(db.String(200), nullable=True)
    description     = db.Column(db.String(500), nullable=True)
    approval_status = db.Column(db.String(20), default='pending')

    drives     = db.relationship('PlacementDrive', backref='company', lazy=True)
    placements = db.relationship('Placement', backref='company', lazy=True)

    def __repr__(self):
        return f'<CompanyProfile {self.company_name} | {self.approval_status}>'

    def as_dict(self):
        return {c.key: getattr(self, c.key) for c in self.__table__.columns}


# PLACEMENT DRIVE (job posting by a company)
class PlacementDrive(db.Model):
    __tablename__ = 'placement_drives'

    id                   = db.Column(db.Integer, primary_key=True)
    company_id           = db.Column(db.Integer, db.ForeignKey('company_profiles.id'), nullable=False)
    job_title            = db.Column(db.String(150), nullable=False)
    job_description      = db.Column(db.String(1000), nullable=True)
    eligibility_branch   = db.Column(db.String(200), nullable=True)
    min_cgpa             = db.Column(db.Float, default=0.0)
    eligibility_year     = db.Column(db.Integer, nullable=True)
    salary               = db.Column(db.Float, nullable=True)
    application_deadline = db.Column(db.DateTime, nullable=True)
    status               = db.Column(db.String(20), default='pending')
    date_created         = db.Column(db.DateTime, default=datetime.utcnow)

    applications = db.relationship('Application', backref='drive', lazy=True)

    def __repr__(self):
        return f'<PlacementDrive {self.job_title} | {self.status}>'

    def as_dict(self):
        return {c.key: getattr(self, c.key) for c in self.__table__.columns}


# APPLICATION (student applies to a drive)
# status flow: applied -> shortlisted -> interview -> offer -> placed / rejected
class Application(db.Model):
    __tablename__ = 'applications'

    id               = db.Column(db.Integer, primary_key=True)
    student_id       = db.Column(db.Integer, db.ForeignKey('student_profiles.id'), nullable=False)
    drive_id         = db.Column(db.Integer, db.ForeignKey('placement_drives.id'), nullable=False)
    application_date = db.Column(db.DateTime, default=datetime.utcnow)
    status           = db.Column(db.String(20), default='applied')
    feedback         = db.Column(db.String(300), nullable=True)
    interview_start = db.Column(db.DateTime, nullable=True)
    interview_end   = db.Column(db.DateTime, nullable=True)
    interview_mode  = db.Column(db.String(50), nullable=True)

    placement = db.relationship('Placement', backref='application', uselist=False)

    __table_args__ = (
        db.UniqueConstraint('student_id', 'drive_id', name='unique_student_drive'),
    )

    def __repr__(self):
        return f'<Application student={self.student_id} drive={self.drive_id} | {self.status}>'

    def as_dict(self):
        return {c.key: getattr(self, c.key) for c in self.__table__.columns}


# PLACEMENT (created only when application status = placed)
class Placement(db.Model):
    __tablename__ = 'placements'

    id             = db.Column(db.Integer, primary_key=True)
    application_id = db.Column(db.Integer, db.ForeignKey('applications.id'), nullable=False, unique=True)
    student_id     = db.Column(db.Integer, db.ForeignKey('student_profiles.id'), nullable=False)
    company_id     = db.Column(db.Integer, db.ForeignKey('company_profiles.id'), nullable=False)
    position       = db.Column(db.String(150), nullable=False)
    salary         = db.Column(db.Float, nullable=True)
    joining_date   = db.Column(db.DateTime, nullable=True)
    date_created   = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Placement student={self.student_id} company={self.company_id}>'

    def as_dict(self):
        return {c.key: getattr(self, c.key) for c in self.__table__.columns}