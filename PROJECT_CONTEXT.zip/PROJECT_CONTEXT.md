# IITM MAD-2 Placement Portal V2 - Project Context

Use this file as context when starting a new chat with Codex or any AI assistant.

## Project Identity

This is an IITM BS MAD-2 project for the May 2026 term.

Project name/problem statement: Placement Portal Application - V2.

The application is a campus placement portal with three roles:

- Admin / Institute Placement Cell
- Company
- Student

The goal is to build a simple, explainable, viva-ready web application that satisfies IITM's mandatory project requirements.

## Mandatory Tech Stack

Do not deviate from this stack:

- Backend: Flask
- Frontend: Vue.js via CDN
- Database: SQLite only
- Styling: Bootstrap only
- Templates: Jinja2 only for entry-point HTML if needed, not for UI logic
- Auth: JWT-based token auth or Flask-Security/session auth
- Caching: Redis only
- Async jobs: Celery + Redis only

Important compliance note:

- Avoid extra frontend/backend libraries unless absolutely required by the allowed stack.
- Bootstrap Icons, Google Fonts, Chart.js, Tailwind, React, PostgreSQL, MySQL, external UI kits, etc. are compliance risks unless they are explicitly part of optional work and acceptable under IITM rules.
- The database must be created programmatically. Do not manually create or edit the SQLite DB with DB Browser.

## IITM Hard Rules

- There must be exactly one admin.
- Admin must be pre-created programmatically after database creation.
- There must be no admin registration flow.
- Students self-register and log in.
- Companies self-register and log in, but dashboard access and drive creation require admin approval.
- Students can apply only to admin-approved placement drives.
- Duplicate applications for the same student and drive must be prevented.
- Code should be simple, modular, and explainable in viva.
- Be ready to explain every line of code and modify code live during viva.
- Keep the same development system for viva.
- Do not share code or push to a public repository.
- Maintain GitHub commit history as proof of originality.

## Submission And Viva Rules

- Submit a single zip file.
- The zip root should contain only the project folder, not loose files.
- Submission must contain at least one `.py` file.
- Submit report as DOCX or PDF, maximum 5 pages.
- Report must include:
  - Student details
  - Problem statement and approach
  - Frameworks and libraries used
  - ER diagram
  - API endpoints
  - AI/LLM declaration
  - Demo video link
- Demo video should be around 3-10 minutes, uploaded to Google Drive with access to anyone with the link.
- Validate the zip using IITM's validation Google Form before final portal submission.
- During L1 viva, the project must run within 10 minutes after checksum verification.
- If the examiner feels the student cannot explain or modify the submitted work, it may be treated as malpractice.

Important dates from the IITM docs:

- Project submission starts: June 10, 2026.
- Deadline for students who completed/passed theory before May 2026 term: July 14, 2026.
- Deadline for May 2026 theory registered/completing students: August 9, 2026.
- Milestone 0 / Git tracker setup is mandatory.

## Core Milestones

Milestone 0: GitHub repository setup

- Private GitHub repo
- README
- Optional `.gitignore`
- Add required IITM collaborator through Git tracker instructions
- Commit message: `Milestone-0 PPA-V2 Setup`

Core milestone: Database models and schema

- User model with role: admin, company, student
- Company profile
- Student profile
- Placement drive / job position
- Application
- Placement
- Relationships between models
- Programmatic admin creation

Core milestone: Authentication and RBAC

- Student registration/login
- Company registration/login
- Admin predefined login only
- Role-specific dashboards
- JWT or Flask-Security/session auth

Core milestone: Admin dashboard and management

- Dashboard stats
- Approve/reject companies
- Approve/reject placement drives
- Search companies/students
- View/manage job postings and applications
- Blacklist/deactivate companies and students

Core milestone: Company dashboard and job/application management

- Company profile registration
- Dashboard access only after admin approval
- Create placement drives
- View applicants
- Shortlist/reject applicants with feedback
- Manage drive status
- Schedule interviews
- Update selection status

Core milestone: Student dashboard and application system

- Student registration/login
- Profile update with education, skills, resume, experience
- View/search approved drives
- Apply to drives
- Track application status
- View interviews and feedback
- View placement history

Core milestone: History and status tracking

- Complete application and placement history
- Prevent duplicate applications
- Approved companies only can create drives
- Students see/apply only to approved drives
- Status flow should include applied, shortlisted, interview, offer/selected, rejected, placed
- Admin/company/student views must respect role ownership

Core milestone: Celery + Redis backend jobs

- Setup Celery worker, Celery Beat, and Redis server
- Daily reminder job:
  - Send reminders to students about upcoming application deadlines or scheduled interviews
  - Can use email, SMS, or Google Chat webhook
- Monthly report job:
  - Generate HTML monthly placement activity report
  - Send to admin, or companies if using milestone wording from alternate doc
  - Include stats such as drives, applications, selections/placements
  - Runs on first day of every month
- User-triggered CSV export:
  - Student can export application history asynchronously
  - Some docs also mention companies exporting application/placement history
  - Job should alert user when complete

Core milestone: Redis caching

- Cache frequently used endpoints
- Suggested endpoints:
  - Student approved drive listings
  - Company search
  - Student search
  - Job/drive listings
- Implement expiry and refresh/invalidation policy.

Optional enhancements should only be attempted after core requirements:

- Responsive UI/PWA-like behavior
- Charts/reports/ATS/resume screener
- Public read-only stats dashboard
- Offer letter generator

## Current Project Structure

Workspace root: `C:\MAD2\MAD2_PROJECT`

Current main folders:

- `backend/`
- `frontend/`
- `kanavu/` local Python virtual environment

Important backend files:

- `backend/app.py`
- `backend/models/__init__.py`
- `backend/routes/auth.py`
- `backend/routes/admin.py`
- `backend/routes/company.py`
- `backend/routes/student.py`
- `backend/create_db.py`
- `backend/seed_test_data.py`
- `backend/constants.py`
- `backend/requirements.txt`
- `backend/instance/placement.db`

Important frontend files:

- `frontend/index.html`
- `frontend/login.html`
- `frontend/register-student.html`
- `frontend/register-company.html`
- `frontend/admin-dashboard.html`
- `frontend/company-dashboard.html`
- `frontend/student-dashboard.html`

## Current Implementation Status

Already mostly implemented:

- Flask app with blueprints
- SQLite database via Flask-SQLAlchemy
- JWT auth via Flask-JWT-Extended
- CORS enabled
- Programmatic DB creation
- Programmatic admin seeding
- Unified `User` model with role
- `StudentProfile`, `CompanyProfile`, `PlacementDrive`, `Application`, and `Placement` models
- Student registration
- Company registration
- Login for all roles
- Role-specific frontend redirects
- Admin company approval/rejection
- Admin drive approval/rejection/close
- Admin student/company deactivate or blacklist
- Admin search for companies and students
- Company dashboard with approval gate
- Company drive creation
- Company applicant viewing
- Company shortlisting/rejection/status updates
- Company interview scheduling
- Company placement creation when marking application as placed
- Student approved-drive listing
- Student eligibility checking by CGPA and branch
- Student duplicate application prevention
- Student application history
- Student placement history
- Student profile editing
- Seed test data covering users, companies, drives, applications, interviews, statuses, and placements

Main missing/high-priority items:

- Celery and Redis are not yet in `requirements.txt`.
- Celery app/tasks are not implemented.
- Daily reminder job is not implemented.
- Monthly report job is not implemented.
- Async CSV export is not implemented.
- Redis caching is not implemented.
- Resume upload flow is incomplete/missing, though `resume_path` exists in the model.
- README and `.gitignore` may be missing.
- Final report/demo/video/submission packaging still need preparation.

Compliance risks noticed:

- Frontend pages currently use Bootstrap Icons CDN.
- Frontend pages currently use Google Fonts CDN.
- IITM docs say Bootstrap only and no other libraries/frameworks, so these should be removed or justified carefully.
- Some text/comments have encoding artifacts like `â€”`, likely from copy/paste encoding. Clean these before submission if time allows.

## Recommended Next Priorities

1. Add README and `.gitignore` for Milestone 0 if not already done.
2. Remove compliance-risk CDN dependencies such as Bootstrap Icons and Google Fonts.
3. Add Celery + Redis dependencies and configuration.
4. Implement Celery tasks:
   - daily reminders
   - monthly HTML report
   - student CSV export
5. Add frontend/API flow for CSV export.
6. Add Redis caching to common read/search endpoints.
7. Add simple resume upload or at least resume link/path handling if required.
8. Prepare viva run instructions:
   - create database
   - seed data
   - run Flask
   - run Redis
   - run Celery worker
   - run Celery beat
   - open frontend pages
9. Prepare report sections:
   - approach
   - ER diagram
   - API endpoint list
   - AI declaration
   - demo video link placeholder

## Useful Test Accounts From Seed Data

Admin:

- username: `admin`
- password: `admin123`

Seeded students use password `test123`:

- `alice_s`
- `bob_k`
- `charlie_p`
- `diana_m`
- `evan_r`
- `fiona_l` is blacklisted/deactivated

Seeded companies use password `test123`:

- `tcs_hr` approved
- `infosys_hr` approved
- `google_hr` pending
- `wipro_hr` rejected

## Development Style To Preserve

- Keep logic simple and viva-explainable.
- Prefer one file per concern:
  - routes
  - models
  - tasks
  - constants/config
- Avoid unnecessary abstractions.
- Add brief comments where they help explain intent.
- Avoid adding unsupported frameworks or clever architecture.
- When editing, preserve existing user work and do not remove unrelated changes.

## Suggested Opening Message For A New Chat

Paste this into a new chat:

```
I am working on an IITM MAD-2 Placement Portal Application V2 project in `C:\MAD2\MAD2_PROJECT`.
Please read `PROJECT_CONTEXT.md` first. Follow the mandatory IITM tech stack: Flask, Vue CDN, Bootstrap only, SQLite, Redis, Celery + Redis, JWT auth. Keep code simple and viva-explainable. Do not add unsupported libraries. The project already has backend/frontend code, but Celery jobs, Redis caching, compliance cleanup, README/submission prep still need work.
```

